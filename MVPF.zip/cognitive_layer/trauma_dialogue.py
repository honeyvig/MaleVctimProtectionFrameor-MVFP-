def trauma_informed_response(user_text):
    if "confused" in user_text.lower():
        return "You are not weak. Confusion is a trauma response."
    return "I am here to support you safely."
