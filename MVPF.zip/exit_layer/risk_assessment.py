def assess_exit_risk(environment):
    if environment.get("surveillance") and environment.get("violence_history"):
        return "HIGH RISK"
    return "MODERATE RISK"
