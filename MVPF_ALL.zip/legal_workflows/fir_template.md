# FIR Template

Victim Name:
Incident Date:
Details:
