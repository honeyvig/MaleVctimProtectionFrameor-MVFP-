class SafetyAgent:
    def act(self, data):
        return 'Safety guidance issued'

class LegalAgent:
    def act(self, data):
        return 'Legal rights explained'

class TraumaAgent:
    def act(self, data):
        return 'Trauma-informed support provided'
