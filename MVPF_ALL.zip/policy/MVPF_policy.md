# MVPF Policy Handbook

Ethical, non-violent, trauma-informed AI framework.
