class HumanoidMock:
    def guide(self, task):
        return f'Humanoid assisting with {task}'
