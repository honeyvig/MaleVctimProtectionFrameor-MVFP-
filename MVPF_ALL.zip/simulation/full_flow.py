print('Simulating full MVPF flow: detection -> support -> exit -> rehab')
