from cryptography.fernet import Fernet
key = Fernet.generate_key()
cipher = Fernet(key)

def secure_store(data: bytes):
    return cipher.encrypt(data)